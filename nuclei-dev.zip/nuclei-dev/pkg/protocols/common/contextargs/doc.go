// Package contextargs implements a generic entity for shared context within workflows
//
// All templates within a workflow shares the same cookiejar and a key-value store with shared items
package contextargs
