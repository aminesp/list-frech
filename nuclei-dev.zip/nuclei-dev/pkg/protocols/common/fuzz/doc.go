// Package fuzz contains the fuzzing functionality for dynamic
// fuzzing of HTTP requests and its respective implementation.
package fuzz
